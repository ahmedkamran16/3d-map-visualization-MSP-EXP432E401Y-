import serial
#MACID:400175864
#Kamram6
#Ahmed Kamran
#pyserial library was used
#python 3.7.7 was used

s = serial.Serial("COM4", 115200)
f= open("tof_radar.xyz","a+")

#print("Opening: " + s.name)


s.write(b'1')           #This program will send a '1' or 0x31

for i in range(360):
    x = s.readline()        # read one byte
    c = x.decode()      # convert byte type to str
    print(c)
    f.write(c)
    
print("Closing: " + s.name)
s.close();
f.close();
